// Module with dependencies
//var restaurantApp = angular.module('restaurantApp', ['ngRoute']);
var restaurantApp = angular.module('restaurantApp', ['ngRoute']);

// Route setup for SPA
restaurantApp.config(function ($routeProvider) {
   $routeProvider
    .when('/menus', {
       templateUrl: 'pages/menus.html',
       controller: 'HomeController'
    })
    .when('/underConstruction', {
       templateUrl: 'pages/underConstruction.html',
       controller: 'HomeController'
    })    
    .when('/reservation', {
       templateUrl: 'pages/reservation.html',
       controller: 'HomeController'
    })
    .when('/contactus', {
       templateUrl: 'pages/contactus.html',
       controller: 'HomeController'
    })
    .when('/admin', {
      templateUrl: 'pages/admin.html',
      controller: 'ReservationListController'
    })
    .when('/reservation', {
      templateUrl: 'pages/reservation.html',
      controller: 'ReservationListController'
    })
    .when('/reservation/edit/:id', {
      templateUrl: 'pages/reservation.html',
      controller: 'ReservationListController'
    })
    .otherwise ({
      redirectTo: "/"
    })
});

restaurantApp.service("ReservationService", function() {

   var reservationService = {};

   reservationService.reservationItems = [
      {id: 1, email: 'bkuz100@hotmail.com', firstName: 'Berine', lastName: 'Kuzava', numGuests: 2, phoneNumber: '(813) 827-2298', reserveDate: '11/10/2022', reserveTime: '06:00 PM', fulfilled: 0},
      {id: 2, email: 'amyr@hotmail.com', firstName: 'Amy', lastName: 'Roberts', numGuests: 4, phoneNumber: '(813) 837-2399', reserveDate: '11/22/2022', reserveTime: '06:30 PM', fulfilled: 0},
      {id: 3, email: 'judyj@hotmail.com', firstName: 'Judy', lastName: 'Jones', numGuests: 2, phoneNumber: '(813) 837-2498',reserveDate: '11/10/2022', reserveTime: '07:00 PM', fulfilled: 0},
      {id: 4, email: 'billyw@hotmail.com', firstName: 'Billy', lastName: 'Watson', numGuests: 2, phoneNumber: '(813) 837-2298',reserveDate: '11/14/2022', reserveTime: '06:15 PM', fulfilled: 0},
      {id: 5, email: 'randyt@hotmail.com', firstName: 'Randy', lastName: 'Tolen', numGuests: 2, phoneNumber: '(813) 837-2298',reserveDate: '11/15/2022', reserveTime: '08:00 PM', fulfilled: 0},
      {id: 6, email: 'markk@hotmail.com', firstName: 'Mark', lastName: 'Kruz', numGuests: 12, phoneNumber: '(813) 837-2298',reserveDate: '11/15/2022', reserveTime: '08:30 PM', fulfilled: 0},
   ];

   reservationService.findById = function(id) {
      for(var item in reservationService.reservationItems) {
         if (reservationService.reservationItems[item].id === id) {
            console.log(reservationService.reservationItems[item]);
            return reservationService.reservationItems[item];
         }
      }
   }

   reservationService.getNewId = function() {

      if (reservationService.id) {
         reservationService.id++;
         return reservationService.id;
      } else {
         var maxId = _.max(reservationService.reservationItems, function(entry) {
            return entry.id;
         })
         reservationService.id = maxId.id + 1;
         return reservationService.id;
      }

   };

   reservationService.save = function(entry) {

      var updatedReservation = reservationService.findById(entry.id);

      if (updatedReservation) {

         updatedReservation.email = entry.email;
         updatedReservation.firstName = entry.firstName;
         updatedReservation.lastName = entry.lastName;
         updatedReservation.numGuests = parseInt(entry.numGuests);
         updatedReservation.phoneNumber = entry.phoneNumber;
         updatedReservation.reserveDate = entry.reserveDate;
         updatedReservation.reserveTime = entry.reserveTime;
         updatedReservation.fulfilled = entry.fulfilled;

      } else {
         entry.id = reservationService.getNewId();
         reservationService.reservationItems.push(entry);
      }

   };

   return reservationService;

})

// Controllers
restaurantApp.controller('HomeController', ['$scope', function($scope) {

   $scope.appTitle = 'MyRestaurant Bar and Grille';

}]);

restaurantApp.controller('ReservationListController', ['$scope', "$routeParams", "$location", "$filter", "ReservationService", function($scope, $routeParams, $location, $filter, ReservationService) {

   $scope.reservationItems = ReservationService.reservationItems;

  // $scope.currentDate = new Date();
  // $scope.reserveDate = $filter(new Date());
  //   $scope.reserveDate, 'MM/dd/yy';

   if (!$routeParams.id) {
      $scope.reservationItem = {id: 0, email: "", firstName: "", lastName: "", numGuests: 0, phoneNumber: "", reserveDate: "", reserveTime: ""}
         
      } else {
         $scope.reservationItem = _.clone(ReservationService.findById(parseInt($routeParams.id)));
   }


   $scope.save = function() {
      ReservationService.save( $scope.reservationItem);
      $location.path("/");
   }

}]);










